(function($) {
    "use strict";
    $('#summernote1').summernote({
        height: 100,
    });
    $('#summernote2').summernote({
        height: 100,
    });
    $('#summernote3').summernote({
        height: 100,
    });
    $('#summernote4').summernote({
        height: 100,
    });
    $('#summernote5').summernote({
        height: 100,
    });
    $('.summernote6').summernote({
        height: 100,
    });

})(jQuery);