<?php $__env->startSection('title'); ?>
Edit Evaluation
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style>
    .solid {
        border: 1px solid #00486e;
        padding: 10px;
    }

    .b_ddd {
        border: 1px solid #ddd;
        padding: 5px;
    }

    .p_top10 {
        padding-top: 10px;
    }

    .p_top5 {
        padding-top: 5px;
    }

    .pd10 {
        padding: 30px;
    }

    table {
        border-collapse: collapse;
    }

    table,
    th,
    td {
        border: 1px solid black;
        padding: 5px;
    }

    table,
    td {

        vertical-align: top;
    }

    .none-bot td {
        border-bottom: none !important;
    }

    .none-top td {
        border-top: none !important;
    }

    .basic {
        background-color: #d9ead3;
    }

    td .i-checks {
        vertical-align: bottom;
        text-align: center;
    }

    .tlink {
        position: relative;
        height: 100%;
    }

    .bimg {
        bottom: 0;
        position: absolute;
    }

    .appro {
        background-color: #b6d7a8;
    }

    .compe {
        background-color: #93c47d;
    }

    .outst {
        background-color: #6aa84f;
    }

    .empty-gray {
        background-color: #808080;
    }
    .note-popover .popover-content,
    .panel-heading.note-toolbar {
        display: none;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcome-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcome-list single-page-breadcome">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcome-heading">
                                <form role="search" class="sr-input-func">
                                    <input type="text" placeholder="Search..." class="search-int form-control">
                                    <a href="#"><i class="fa fa-search"></i></a>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <ul class="breadcome-menu">
                                <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                </li>
                                <li><span class="bread-blod">Evaluation criteria 2</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- accordion start-->
<div class="edu-accordion-area mg-b-15">
    <div class="container-fluid">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 solid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="tab-content-details mg-b-30">
                        <h2>Evaluation</h2>
                    </div>
                    <div class="tab-content-details mg-b-30">
                        <h3><?php echo e($schedule->session->name); ?>/<?php echo e($schedule->teacher->fullname); ?>

                        </h3>
                    </div>
                </div>
            </div>
            <form method="post">
                <?php echo e(csrf_field()); ?>

                <input type="text" name="schedule" hidden value="<?php echo e($schedule->id); ?>">
                <input type="text" name="teacher" hidden value="<?php echo e($schedule->teacher->id); ?>">
                <input type="text" name="subject" hidden value="<?php echo e($schedule->id_subject); ?>">

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Time:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <div class="data-custon-pick" id="data_1">
                                        <div class="input-group date">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                            <input type="text" name="time" class="form-control"
                                                value="<?php echo e(date('m/d/Y')); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Lesson content:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <textarea class="form-control" name="content" id="summernote1" rows="3"></textarea>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Objective:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <textarea class="form-control" name="objective" id="summernote2" cols="30"
                                        rows="5"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Lesson flow:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <textarea class="form-control" name="lesson_flow" id="summernote3" cols="30"
                                        rows="5"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Strengths:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <textarea class="form-control" name="strengths" id="summernote4" cols="30"
                                        rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group-inner">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <label class="login2 pull-right pull-right-pro">Areas for
                                        improvement:</label>
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                                    <textarea class="form-control" name="improvement" id="summernote5"
                                        rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <table>
                    <thead>
                        <th></th>
                        <th></th>
                        <th width=20%>Basic(x1)</th>
                        <th width=20%>Approaching(x2)</th>
                        <th width=20%>Competent(x3)</th>
                        <th width=20%>Outstanding(x4)</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="6" style="background-color: #134f5c; color: #fff;">
                                <b>PART 1 - LESSON PLANNING / CRITERIA 2</b>
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="6"><b>1. Lesson Planning</b></td>
                            <td rowspan="2"><b>1.1. Objectives</b></td>
                            <td class="basic">
                                <p class="login2 pull-left pull-left-pro">Lesson objective is aligned with level
                                    outcomes.</p>
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">Objectives are performance-based </p>
                            </td>
                            <td class="compe">
                                <p class="login2 pull-left pull-left-pro">T anticipates problems and plans solutions.
                                </p>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_1_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_1_compe" value="3">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="4"><b>1.2. Sequence & Balance</b></td>
                            <td class="basic">
                                <p class="login2 pull-left pull-left-pro">LP provides brief task description, task aim,
                                    and procedure.</p>
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">Lesson is logically staged for each learning
                                    activity to contribute to achieve the lesson outcomes.</p>
                            </td>
                            <td class="compe">
                                <p class="login2 pull-left pull-left-pro">LP shows diagnostic, formative, or summative
                                    assessments </p>
                            </td>
                            <td class="outst">
                                <p class="login2 pull-left pull-left-pro">LP shows an innovative approach in integrating
                                    language skills with communication/ collaboration </p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_1_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_1_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_1_outst" value="4">
                                </div>
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td class="empty-gray">
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">There is appropriate time allocation to
                                    learning activities and transitions.</p>
                            </td>
                            <td class="compe">
                                <p class="login2 pull-left pull-left-pro">LP shows differentiation principles to
                                    facilitate learning for multiple learner types.</p>
                            </td>
                            <td class="outst">
                                <p class="login2 pull-left pull-left-pro">LP shows an innovative approach in integrating
                                    language skills with creativity/critical thinking</p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="empty-gray">
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_2_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_2_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_1_2_2_outst" value="4">
                                </div>
                            </td>
                        </tr>
                        <!--part2-->
                        <tr>
                            <td colspan="6" style="background-color: #134f5c; color: #fff;"><b>PART 2 - CLASSROOM
                                    ENVIRONMENT</b></td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="6"><b>2A. Managing Classroom Space, Materials & Procedures</b></td>
                            <td rowspan="2"><b>2A.1. Space</b></td>
                            <td class="basic">
                                <p class="login2 pull-left pull-left-pro">T checks/ ensures Ss' desks and chairs are
                                    arranged for safe movement.</p>
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">T checks/ ensures classroom setup allows Ss to
                                    have access to instruction with limited distractions. </p>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a1_appro" value="2">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="2"><strong>2A.2. Materials</strong> </td>
                            <td class="basic">
                                <p class="login2 pull-left pull-left-pro">T provides a variety of materials.</p>
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">T provides visually appealing materials.</p>
                            </td>
                            <td class="compe">
                                <p class="login2 pull-left pull-left-pro">T adequately exploits each presented material
                                </p>
                            </td>
                            <td class="outst">
                                <p class="login2 pull-left pull-left-pro">T makes creative use of teaching aids that
                                    highly motivates and challenges Ss</p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a2_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a2_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a2_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a2_outst" value="4">
                                </div>
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="2"><strong>2A.3. Procedures</strong> </td>
                            <td class="basic">
                                <p class="">T gives clear & orderly instructions for transitions and other routines </p>
                            </td>
                            <td class="appro">
                                <p class="login2 pull-left pull-left-pro">T executes transitions & other routines
                                    smoothly with minimal loss of instructional time.</p>

                            </td>
                            <td class="compe">
                                <p class="login2 pull-left pull-left-pro">Ss contribute to carrying out procedures</p>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a3_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a3_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2a3_compe" value="3">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>

                        <tr class="none-bot">
                            <td rowspan="4"><b>2B. Managing Student Behavior</b></td>
                            <td rowspan="2"><b>2B.1. Setting & Monitoring Rules/Expectations </b></td>
                            <td class="basic">
                                <p>
                                    T clearly states/ displays classroom rules, expectations.
                                </p>
                            </td>
                            <td class="appro">
                                <p>
                                    T demonstrates continuous active supervision across the classroom & activities.
                                </p>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b1_appro" value="2">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="2"><strong>2B.2. Responding to & Fostering Student Behavior</strong> </td>
                            <td class="basic">
                                <p>
                                    T acknowledges Ss' positive behaviors.
                                </p>
                            </td>
                            <td class="appro">
                                <p>
                                    T frequently reminds Ss of expected positive behaviors.
                                </p>
                            </td>
                            <td class="compe">
                                <p>
                                    T positively & effectively handles misbehaviors without hugely disrupting the class
                                    flow and attention.
                                </p>
                            </td>
                            <td class="outst">
                                <p>
                                    At least 80% Ss follow classroom procedures and show appropriate behavior.
                                </p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b2_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b2_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b2_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2b2_outst" value="4">
                                </div>
                            </td>
                        </tr>

                        <tr class="none-bot">
                            <td rowspan="8"><b>2C. Building characters and promoting academic mindset</b></td>
                            <td rowspan="2"><b>2C. 1. Sense of belonging and interpersonal character</b></td>
                            <td class="basic">
                                <p>
                                    T builds rapport with students
                                </p>
                            </td>
                            <td class="appro">
                                <p>
                                    T demonstrates understanding of Ss & their interests
                                </p>
                            </td>
                            <td class="compe">
                                <p>
                                    T shows sensitivity to Ss' inclinations.
                                </p>
                            </td>
                            <td class="outst">
                                <p>
                                    Most Ss naturally feel and show caring and empathy with peers and Ts
                                </p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c1_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c1_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c1_outst" value="4">
                                </div>
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td rowspan="4"><b>2C.2. Growth mindset, self-efficacy and intrapersonal character</b></td>
                            <td class="basic">
                                <p>
                                    T encourages Ss to keep going until they achieve the lesson objectives/ activities.
                                </p>
                            </td>
                            <td class="appro">
                                <p>
                                    T reinforces high expectations of student effort.
                                </p>
                            </td>
                            <td class="compe">
                                <p>
                                    Most Ss achieve objectives of the lesson/ activities with T's support/
                                    encouragement.
                                </p>
                            </td>
                            <td class="outst">
                                <p>
                                    Most Ss in class remain at an activity by themselves to complete work of high
                                    quality
                                </p>
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c2_1_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c2_1_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c2_1_compe" value="3">
                                </div>
                            </td>
                            <td class="outst">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c2_1_outst" value="4">
                                </div>
                            </td>
                        </tr>
                        <tr class="none-bot">
                            <td class="basic">
                                <p>
                                    T acknowledges Ss' effort and improvement.
                                </p>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c2_2_basic" value="1">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>

                        <tr class="none-bot">
                            <td rowspan="2"><b>2C.3. Relevance and intellectual character</b></td>
                            <td class="basic">
                                <p>
                                    T shows interest in delivering the lesson.
                                </p>
                            </td>
                            <td class="appro">
                                <p>
                                    T explains the importance of learning/ subject/ lesson content
                                </p>
                            </td>
                            <td class="compe">
                                <p>
                                    Most Ss demonstrate a genuine desire to understand the lesson
                                </p>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>
                        <tr class="none-top" style="text-align: center">
                            <td class="basic">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c3_basic" value="1">
                                </div>
                            </td>
                            <td class="appro">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c3_appro" value="2">
                                </div>
                            </td>
                            <td class="compe">
                                <div class="i-checks">
                                    <input type="checkbox" name="part_2c3_compe" value="3">
                                </div>
                            </td>
                            <td class="empty-gray">
                            </td>
                        </tr>

                    </tbody>
                </table>

                <div class="row pd10">
                    <div class="admin-pro-accordion-wrap shadow-inner responsive-mg-b-30">

                        <div class="row pull-right">
                            <input type="submit" class="btn btn-primary mb-2"
                                onclick="return confirm('Are you sure you want to submit the evalution?')"
                                formaction="<?php echo e(route('evaluation_complete')); ?>" value="complete">
                            <input type="submit" class="btn btn-primary"
                                onclick="return confirm('Are you sure you want to save to draft?')"
                                formaction="<?php echo e(route('evaluation_save')); ?>" value="save to draft">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- icheck JS ============================================ -->
<script src="be/js/icheck/icheck.min.js"></script>
<script src="be/js/icheck/icheck-active.js"></script>
<script src="be/js/datapicker/bootstrap-datepicker.js"></script>
<script src="be/js/datapicker/datepicker-active.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('be/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\olympia\resources\views/be/schedules/evaluation2.blade.php ENDPATH**/ ?>