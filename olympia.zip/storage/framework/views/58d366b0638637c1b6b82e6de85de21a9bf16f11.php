Dear <?php echo e($evaluation->teacher->fullname); ?>, 
<br> <br>
Thank you for having me in your class. This is the teaching feedback for your <?php echo e($evaluation->schedule->class); ?> 
on <?php echo e($evaluation->schedule->day); ?> <?php echo e($evaluation->test); ?> at <?php echo e($evaluation->schedule->time); ?> 
<br>
<br>
<b>Strengths:</b>
<br>
<?php echo $evaluation->strengths; ?>

<br><br>
<b>Areas for improvement:</b>
<br>
<?php echo $evaluation->improvement; ?>

<br><br>
Thank you for your hard work and dedication.
<br> <br>
Kind regards,
<br> <br>
IEG Academic<?php /**PATH C:\xampp\htdocs\aca2\resources\views/mail/cot.blade.php ENDPATH**/ ?>