<?php if(count($errors) > 0): ?>
<div class="alert alert-danger alert-dismissible fade in">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e($err); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php if(session('msg')): ?>
<div style="
position: fixed;
    z-index:9999; top: 30%; " class="alert alert-success alert-dismissible fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e(session('msg')); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\aca\resources\views/msg.blade.php ENDPATH**/ ?>