<?php echo e($evaluation->schedule->teacher->email); ?>

total: <?php echo e($total = (array_sum($evaluation->part2a)+array_sum($evaluation->part2b)+array_sum($evaluation->part2c)+array_sum($evaluation->part2d)
    +array_sum($evaluation->part3a)+array_sum($evaluation->part3b)+array_sum($evaluation->part3c)+array_sum($evaluation->part3d)
    +array_sum($evaluation->part4a)+array_sum($evaluation->part4b)+array_sum($evaluation->part4c))); ?><?php /**PATH C:\xampp\htdocs\aca\resources\views/mail/cot.blade.php ENDPATH**/ ?>