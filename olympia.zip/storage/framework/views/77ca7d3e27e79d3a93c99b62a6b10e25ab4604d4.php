<?php $__env->startSection('title'); ?>
Booking Schedule
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcome-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcome-list single-page-breadcome">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcome-heading">
                                <form role="search" class="sr-input-func">
                                    <input type="text" placeholder="Search..." class="search-int form-control">
                                    <a href="#"><i class="fa fa-search"></i></a>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <ul class="breadcome-menu">
                                <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                </li>
                                <li><span class="bread-blod">Schedule</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Single pro tab review Start-->
<!-- Single pro tab review Start-->
<div class="single-pro-review-area mt-t-30 mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-payment-inner-st">
                    <ul id="myTabedu1" class="tab-review-design">
                        <li class="active"><a href="#description">Schedule</a></li>
                    </ul>
                    <div id="myTabContent" class="tab-content custom-product-edit">
                        <div class="product-tab-list tab-pane fade active in" id="description">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="review-content-section">
                                        <div id="dropzone1" class="pro-ad">
                                            <form action="<?php echo e(route('default_result_booking')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="row">
                                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                                        <div class="form-group">
                                                            <select name="location" id="location" class="form-control">
                                                                <option value="none" selected="" hidden disabled="">
                                                                    Select
                                                                    Address</option>
                                                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($address->id); ?>"><?php echo e($address->name); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                                        <div class="form-group">
                                                            <select name="teacher" id="teacher" class="form-control">
                                                                <option value="none" selected="" hidden disabled="">
                                                                    Select
                                                                    Tearcher</option>
                                                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($teacher->id); ?>">
                                                                    <?php echo e($teacher->fullname); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                                        <div class="form-group">
                                                            <select name="day_id" class="form-control">
                                                                <option value="none" selected="" hidden disabled="">
                                                                    Select day</option>
                                                                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($day->id); ?>">
                                                                    <?php echo e($day->name); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="payment-adress">
                                                            <button type="submit"
                                                                class="btn btn-primary waves-effect waves-light">Submit</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <?php if(isset($booking)): ?>
                                                    <div class="row" style="padding-top:50px;">
                                                        <div>
                                                            <table id="example"
                                                                class="table table-striped table-bordered"
                                                                style="width:100%">
                                                                <thead>
                                                                    <tr
                                                                        style="color: #fff; text-align: center; background-color: #114275;">
                                                                        <th>Location</th>
                                                                        <th>Teacher</th>
                                                                        <th>Day</th>
                                                                        <th>Class</th>
                                                                        <th>Session</th>
                                                                        <th>Booking</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody style="text-align:center; line-height: 120px">
                                                                    <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($book->teacher->coso->name); ?></td>
                                                                        <td><?php echo e($book->teacher->fullname); ?></td>
                                                                        <td><?php echo e($book->day->name); ?></td>
                                                                        <td><?php echo e($book->dclass); ?></td>
                                                                        <td><?php echo e($book->session->name); ?>

                                                                            <?php echo e($book->session->time); ?> </td>
                                                                        <td>
                                                                            <?php if($book->booking == null): ?>

                                                                            <form action="<?php echo e(route('schedule_booking')); ?>"
                                                                                method="post">
                                                                                <?php echo e(csrf_field()); ?>

                                                                                <input type="text" hidden
                                                                                    name="id_location"
                                                                                    value="<?php echo e($book->teacher->coso->id); ?>">
                                                                                <input type="text" hidden name="day"
                                                                                    value="<?php echo e($book->day->name); ?>">
                                                                                <input type="text" hidden
                                                                                    name="id_teacher"
                                                                                    value="<?php echo e($book->teacher->id); ?>">
                                                                                <input type="text" hidden name="session"
                                                                                    value="<?php echo e($book->session->time); ?>">
                                                                                <input type="text" hidden name="class"
                                                                                    value="<?php echo e($book->dclass); ?>">
                                                                                <input type="submit" class="submit-btn"
                                                                                    value="Booking">
                                                                            </form>
                                                                            <?php else: ?>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                            <script>
                                                                $(document).ready(function() {
                                                                        $('#example').DataTable();
                                                                    } );
                                                            </script>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="row">
                                                        <table id="example" class="table table-striped table-bordered"
                                                            style="width:100%">
                                                            <thead>
                                                                <tr
                                                                    style="color: #fff; text-align: center; background-color: #114275;">
                                                                    <th></th>
                                                                    <th>ID</th>
                                                                    <th>Location</th>
                                                                    <th>Teacher</th>
                                                                    <th>Day</th>
                                                                    <th>session</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $defaultschedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td></td>
                                                                    <td><?php echo e($schedule->id); ?></td>
                                                                    <td><?php echo e($schedule->teacher->coso->name); ?></td>
                                                                    
                                                                    <td><?php echo e($schedule->teacher->fullname); ?></td>
                                                                    <td><?php echo e($schedule->day->name); ?></td>
                                                                    <td><?php echo e($schedule->session->name); ?>:
                                                                        <?php echo e($schedule->session->time); ?></td>
                                                                    <td>
                                                                        <?php if($schedule->booking == null): ?>
                                                                        <form action="<?php echo e(route('schedule_booking')); ?>"
                                                                            method="post">
                                                                            <?php echo e(csrf_field()); ?>

                                                                            <input type="text" hidden name="id_location"
                                                                                value="<?php echo e($schedule->teacher->coso->id); ?>">
                                                                            <input type="text" hidden name="day"
                                                                                value="<?php echo e($schedule->day->name); ?>">
                                                                            <input type="text" hidden name="id_teacher"
                                                                                value="<?php echo e($schedule->teacher->id); ?>">
                                                                            <input type="text" hidden name="session"
                                                                                value="<?php echo e($schedule->session->time); ?>">
                                                                            <input type="text" hidden name="class"
                                                                                value="<?php echo e($schedule->dclass); ?>">
                                                                            <input type="submit" class="submit-btn"
                                                                                value="Booking">
                                                                        </form>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                        <script>
                                                            $(document).ready(function() {
                                                                    $('#example').DataTable();
                                                                } );
                                                        </script>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $("#location").change(function(){
            var id_location = $(this).val();
            // alert(id_location);
            $.get("admin/ajax/location/"+id_location, function(data){
                $("#teacher").html(data);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('be/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\olympia\resources\views/be/default_schedules/booking.blade.php ENDPATH**/ ?>