<div class="left-sidebar-pro">
    <nav id="sidebar" class="">
        <div class="sidebar-header">
            <a href="index.html"><img class="main-logo" src="be/img/logo.png" alt="" /></a>
            <strong><a href="index.html"><img src="be/img/logo.png" alt="" /></a></strong>
        </div>
        <div class="left-custom-menu-adp-wrap comment-scrollbar">
            <nav class="sidebar-nav left-sidebar-menu-pro">
                <ul class="metismenu" id="menu1">
                    <li>
                        <a title="Landing Page" href="/admin/dashboard" aria-expanded="false"><span
                                class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span>
                            <span class="mini-click-non">Dashboard</span></a>
                    </li>
                </ul>
            </nav>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\aca2\resources\views/teachers/layouts/left_menu.blade.php ENDPATH**/ ?>