
<table id="customers">
    <thead>
        <tr>
            <th style="background-color: #b6d7a8;">id</th>
            <th style="background-color: #b6d7a8;">Ma_lop</th>
            <th style="background-color: #b6d7a8;">Ngay_giang</th>
            <th style="background-color: #b6d7a8;">nguoi danh gia</th>
            <th style="background-color: #b6d7a8;">tk nguoi danh gia</th>
            <th style="background-color: #b6d7a8;">gv</th>
            <th style="background-color: #b6d7a8;">Email gv</th>
            <th style="background-color: #b6d7a8;">uu diem</th>
            <th style="background-color: #b6d7a8;">nhuoc diem</th>
            <th style="background-color: #b6d7a8;">Ten</th>
            <th style="background-color: #b6d7a8;">Diem</th>
            <th style="background-color: #b6d7a8;">IsDat</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.1</td>
            <?php if($evaluation->part1['p1a1']['basic'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a1']['basic']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.1</td>
            <?php if($evaluation->part1['p1a1']['appro'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a1']['appro']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['basic_1'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['basic_1']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['appro_1'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['appro_1']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['compe_1'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['compe_1']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['outst_1'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['outst_1']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['appro_2'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['appro_2']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['compe_2'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['compe_2']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            <?php if($evaluation->part1['p1a2']['outst_2'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a2']['outst_2']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            <?php if($evaluation->part1['p1a3']['basic'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a3']['basic']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            <?php if($evaluation->part1['p1a3']['appro'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a3']['appro']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            <?php if($evaluation->part1['p1a3']['compe'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1a3']['compe']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            <?php if($evaluation->part1['p1b1']['basic'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1b1']['basic']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            <?php if($evaluation->part1['p1b1']['appro'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1b1']['appro']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            <?php if($evaluation->part1['p1b1']['compe'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1b1']['compe']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <tr>
            <td><?php echo e($evaluation->id); ?></td>
            <td><?php echo e($evaluation->subject->name); ?></td>
            <td><?php echo e($evaluation->schedule->class); ?></td>
            <td><?php echo e($evaluation->user->name); ?></td>
            <td><?php echo e($evaluation->user->email); ?></td>
            <td><?php echo e($evaluation->teacher->fullname); ?></td>
            <td><?php echo e($evaluation->teacher->email); ?></td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            <?php if($evaluation->part1['p1b1']['outst'] == null): ?>
            <td>0</td>
            <td>FALSE</td>
            <?php else: ?>
            <td><?php echo e($evaluation->part1['p1b1']['outst']); ?></td>
            <td>TRUE</td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\olympia\resources\views/excel/exportcot.blade.php ENDPATH**/ ?>