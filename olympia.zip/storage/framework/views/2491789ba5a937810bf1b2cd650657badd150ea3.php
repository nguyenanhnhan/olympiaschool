<div <?php if(Auth::user()->role == 2): ?>
    hidden
    <?php endif; ?> class="left-sidebar-pro">
    <nav id="sidebar" class="">
        <div class="sidebar-header">
            <a href="<?php echo e(route('select_school')); ?>"><img class="main-logo" src="be/img/logo.png" alt="" /></a>
            <strong><a href="<?php echo e(route('select_school')); ?>"><img src="be/img/logo.png" alt="" /></a></strong>
        </div>
        <div class="left-custom-menu-adp-wrap comment-scrollbar">
            <nav class="sidebar-nav left-sidebar-menu-pro">
                <ul class="metismenu" id="menu1">
                    <li>
                        <a title="Landing Page" href="/admin/dashboard" aria-expanded="false"><span
                                class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span>
                            <span class="mini-click-non">Dashboard</span></a>
                    </li>
                    <li class="<?php echo e(request()->is('admin/teachers*') ? 'active' : ''); ?>">
                        <a class="has-arrow" href="all-professors.html" aria-expanded="false"><span
                                class="educate-icon educate-professor icon-wrap"></span> <span
                                class="mini-click-non">Teachers</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="All Professors" href="admin/teachers/list"><span class="mini-sub-pro">All
                                        Teachers</span></a></li>
                            <li><a title="Add Professor" href="admin/teachers/add"><span class="mini-sub-pro">Add
                                        Teachers</span></a></li>
                        </ul>
                    </li>
                    <li class="<?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                        <a class="has-arrow" href="all-students.html" aria-expanded="false"><span
                                class="educate-icon educate-student icon-wrap"></span> <span
                                class="mini-click-non">Admin</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="All Students" href="admin/users/list"><span class="mini-sub-pro">All
                                        Admins</span></a></li>
                            <li><a title="Add Students" href="admin/users/add"><span class="mini-sub-pro">Add
                                        Admin</span></a></li>
                        </ul>
                    </li>
                    
                    <li class="<?php echo e(request()->route()->named('default*') ? 'active' : ''); ?>">
                        <a class="has-arrow" href="all-students.html" aria-expanded="false"><span
                                class="educate-icon educate-student icon-wrap"></span> <span
                                class="mini-click-non">Default Schedules</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="All schedule" href="<?php echo e(route('default_schedule_show')); ?>"><span
                                        class="mini-sub-pro">All
                                        Default Schedules</span></a></li>
                            <li><a title="Add schedule" href="<?php echo e(route('default_schedule_create')); ?>"><span
                                        class="mini-sub-pro">Add
                                        Default Schedules</span></a></li>
                        </ul>
                    </li>
                    
                </ul>
            </nav>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\aca2\resources\views/be/layouts/left_menu.blade.php ENDPATH**/ ?>