<?php $__env->startSection('title'); ?>
add new teacher
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Single pro tab review Start-->
<!-- Single pro tab review Start-->
<div class="single-pro-review-area mt-t-30 mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-payment-inner-st">
                    <ul id="myTabedu1" class="tab-review-design">
                        <li class="active"><a href="#description">Trungbinhf</a></li>
                    </ul>
                    <div id="myTabContent" class="tab-content custom-product-edit">
                        <div class="product-tab-list tab-pane fade active in" id="description">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="review-content-section">
                                        <div id="dropzone1" class="pro-ad">
                                            <form action="<?php echo e(route('ranking_result')); ?>" method="POST"
                                                enctype="multipart/form-data">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="row">
                                                    <div class="col-lg-4 col-md-4 col-md-offset-4 col-sm-4 col-xs-12">
                                                        <div class="form-group">
                                                            <select name="id_teacher" class="form-control">
                                                                <option value="none" selected="" hidden disabled="">
                                                                    Select
                                                                    Tearcher</option>
                                                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tearcher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tearcher->id); ?>">
                                                                    <?php echo e($tearcher->fullname); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="payment-adress">
                                                            <button type="submit"
                                                                class="btn btn-primary waves-effect waves-light">Submit</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <?php if(isset($ranking)): ?>
                                                    <div class="row" style="padding-top:50px;">
                                                        <div>
                                                            <table
                                                                class="table table-striped table-bordered table-hover"
                                                                id="example-table" cellspacing="0" width="100%">
                                                                <thead>
                                                                    <tr
                                                                        style="color: #fff; text-align: center; background-color: #114275;">
                                                                        <th>Location</th>
                                                                        <th>Teacher</th>
                                                                        <th>2a</th>
                                                                        <th>2b</th>
                                                                        <th>2c</th>
                                                                        <th>2d</th>
                                                                        <th>3a</th>
                                                                        <th>3b</th>
                                                                        <th>3c</th>
                                                                        <th>3d</th>
                                                                        <th>4a</th>
                                                                        <th>4b</th>
                                                                        <th>4c</th>
                                                                        
                                                                        <th>total</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody style="text-align:center; line-height: 120px">
                                                                    <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($rank->schedule->location->name); ?> / <?php echo e($rank->schedule->class); ?></td>
                                                                    <td><?php echo e($rank->teacher->fullname); ?></td>
                                                                    <td><?php echo e($p2a = array_sum($rank->part2a['p2a1']) + array_sum($rank->part2a['p2a2']) + array_sum($rank->part2a['p2a3'])); ?></td>
                                                                    <td><?php echo e($p2b = array_sum($rank->part2b['p2b1']) + array_sum($rank->part2b['p2b2'])); ?></td>
                                                                    <td><?php echo e($p2c = array_sum($rank->part2c['p2c'])); ?></td>
                                                                    <td><?php echo e($p2d = array_sum($rank->part2d['p2d1']) + array_sum($rank->part2d['p2d2'])); ?></td>
                                                                    <td><?php echo e($p3a = array_sum($rank->part3a['p3a1']) + array_sum($rank->part3a['p3a2']) + array_sum($rank->part3a['p3a3']) + array_sum($rank->part3a['p3a4'])); ?></td>
                                                                    <td><?php echo e($p3b = array_sum($rank->part3b['p3b1']) + array_sum($rank->part3b['p3b2'])); ?></td>
                                                                    <td><?php echo e($p3c = array_sum($rank->part3c['p3c1']) + array_sum($rank->part3c['p3c2'])); ?></td>
                                                                    <td><?php echo e($p3d = array_sum($rank->part3d['p3d1']) + array_sum($rank->part3d['p3d2'])); ?></td>
                                                                    <td><?php echo e($p4a = array_sum($rank->part4a['p4a1']) + array_sum($rank->part4a['p4a2'])); ?></td>
                                                                    <td><?php echo e($p4b = array_sum($rank->part4b['p4b'])); ?></td>
                                                                    <td><?php echo e($p4c = array_sum($rank->part4c['p4c'])); ?></td>
                                                                    <td>
                                                                            <?php echo e($total1 = $p2a + $p2b + $p2c + $p2d + $p3a + $p3b + $p3c + $p3d + $p4a + $p4b + $p4c); ?>

                                                                        </td>
                                                                        
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $test = 100;
                                                                    ?>
                                                                    <tr style="background-color: #a7a7a7">
                                                                        <td colspan="2"><b>trung bình:</b></td>
                                                                    <td><?php echo e($med_p2a = number_format($total_p2a/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p2b = number_format($total_p2b/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p2c = number_format($p2c/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p2d = number_format($total_p2d/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p3a = number_format($total_p3a/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p3b = number_format($total_p3b/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p3c = number_format($total_p3c/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p3d = number_format($total_p3d/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p4a = number_format($total_p4a/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p4b = number_format($total_p4b/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_p4c = number_format($total_p4c/count($ranking),2)); ?></td>
                                                                    <td><?php echo e($med_total = number_format($total/count($ranking),2)); ?></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <div class="row text-center">
                                                                <b>
                                                                    Ranking: 
                                                                </b>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="row" style="padding-top:50px;">
                                                        <div>
                                                            <h3>Ranking</h3>
                                                            <table
                                                                class="table table-striped table-bordered table-hover"
                                                                id="example-table" cellspacing="0" width="100%">
                                                                <thead>
                                                                    <tr style="color: #fff; text-align: center; background-color: #114275;">
                                                                        <th colspan="9" style="text-align: center">Ranking</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody style="text-align:center; line-height: 120px">
                                                                    <tr
                                                                        style=" background-color: #a7d2ff;">
                                                                        <td>2A <br> Ineffective</td>
                                                                        <td>2B <br> Ineffective</td>
                                                                        <td>2C <br> Ineffective</td>
                                                                        <td>2D <br> Ineffective</td>
                                                                        <td>3A <br> Ineffective</td>
                                                                        <td>3B <br> Ineffective</td>
                                                                        <td>3C <br> Ineffective</td>
                                                                        <td>3D <br> Ineffective</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>2A.1 <br> Developing</td>
                                                                        <td>2B.1 <br> Developing</td>
                                                                        <td>2C.1 <br> Developing</td>
                                                                        <td>2D.1 <br> Developing</td>
                                                                        <td>3A.1 <br> Developing</td>
                                                                        <td>3B.1 <br> Developing</td>
                                                                        <td>3C.1 <br> Developing</td>
                                                                        <td>3D.1 <br> Developing</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>2A.2 <br> Developing</td>
                                                                        <td>2B.2 <br> Developing</td>
                                                                        <td>2C.2 <br> Developing</td>
                                                                        <td>2D.2 <br> Developing</td>
                                                                        <td>3A.2 <br> Developing</td>
                                                                        <td>3B.2 <br> Developing</td>
                                                                        <td>3C.2 <br> Developing</td>
                                                                        <td>3D.2 <br> Developing</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>2A.3 <br> Developing</td>
                                                                        <td>2B.3 <br> Developing</td>
                                                                        <td>2C.3 <br> Developing</td>
                                                                        <td>2D.3 <br> Developing</td>
                                                                        <td>3A.3 <br> Developing</td>
                                                                        <td>3B.3 <br> Developing</td>
                                                                        <td>3C.3 <br> Developing</td>
                                                                        <td>3D.3 <br> Developing</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>2A.4 <br> Developing</td>
                                                                        <td>2B.4 <br> Developing</td>
                                                                        <td>2C.4 <br> Developing</td>
                                                                        <td>2D.4 <br> Developing</td>
                                                                        <td>3A.4 <br> Developing</td>
                                                                        <td>3B.4 <br> Developing</td>
                                                                        <td>3C.4 <br> Developing</td>
                                                                        <td>3D.4 <br> Developing</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="row">
                                                        <table id="table" data-toggle="table" data-pagination="true"
                                                            data-search="true" data-show-columns="true"
                                                            data-show-pagination-switch="true" data-show-refresh="true"
                                                            data-key-events="true" data-show-toggle="true"
                                                            data-resizable="true" data-cookie="true"
                                                            data-cookie-id-table="saveId" data-show-export="false"
                                                            data-click-to-select="true" data-toolbar="#toolbar">
                                                            <thead>
                                                                <tr>
                                                                    <th data-field="state" data-checkbox="true"></th>
                                                                    <th data-field="id">ID</th>
                                                                    <th data-field="fullname" data-editable="true">
                                                                        Location</th>
                                                                    <th data-field="image" data-editable="false">Teacher
                                                                    </th>
                                                                    <th data-field="info" data-editable="false">Class
                                                                    </th>
                                                                    <th data-field="email" data-editable="true">
                                                                        Date/Time</th>
                                                                    <th data-field="action">Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td></td>
                                                                    <td><?php echo e($schedule->id); ?></td>
                                                                    <td><?php echo e($schedule->location->name); ?></td>
                                                                    <td><?php echo e($schedule->teacher->fullname); ?></td>
                                                                    <td><?php echo e($schedule->class); ?></td>
                                                                    <td><?php echo e(date('D', strtotime($schedule->time1))); ?>/<?php echo e($schedule->time1); ?>

                                                                    </td>
                                                                    <td>
                                                                        <?php if($schedule->booking == null): ?>
                                                                        <form action="admin/schedules/add_booking"
                                                                            method="post">
                                                                            <?php echo e(csrf_field()); ?>

                                                                            <input type="text" hidden name="id"
                                                                                value="<?php echo e($schedule->id); ?>" id="">
                                                                            <input type="submit" class="submit-btn"
                                                                                value="Booking">
                                                                        </form>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!DOCTYPE HTML>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('be/layouts/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aca\resources\views/be/evaluation/ranking.blade.php ENDPATH**/ ?>