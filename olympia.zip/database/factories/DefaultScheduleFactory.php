<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DefaultSchedule;
use Faker\Generator as Faker;

$factory->define(DefaultSchedule::class, function (Faker $faker) {
    return [
        //
    ];
});
