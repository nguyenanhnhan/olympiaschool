<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\schedule;
use Faker\Generator as Faker;

$factory->define(schedule::class, function (Faker $faker) {
    return [
        //
    ];
});
