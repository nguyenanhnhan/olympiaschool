<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lesson_plan extends Model
{
    //
}
