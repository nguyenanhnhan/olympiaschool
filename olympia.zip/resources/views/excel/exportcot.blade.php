
<table id="customers">
    <thead>
        <tr>
            <th style="background-color: #b6d7a8;">id</th>
            <th style="background-color: #b6d7a8;">Ma_lop</th>
            <th style="background-color: #b6d7a8;">Ngay_giang</th>
            <th style="background-color: #b6d7a8;">nguoi danh gia</th>
            <th style="background-color: #b6d7a8;">tk nguoi danh gia</th>
            <th style="background-color: #b6d7a8;">gv</th>
            <th style="background-color: #b6d7a8;">Email gv</th>
            <th style="background-color: #b6d7a8;">uu diem</th>
            <th style="background-color: #b6d7a8;">nhuoc diem</th>
            <th style="background-color: #b6d7a8;">Ten</th>
            <th style="background-color: #b6d7a8;">Diem</th>
            <th style="background-color: #b6d7a8;">IsDat</th>
        </tr>
    </thead>
    <tbody>
        @foreach($evaluations as $evaluation)
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.1</td>
            @if ($evaluation->part1['p1a1']['basic'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a1']['basic'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.1</td>
            @if ($evaluation->part1['p1a1']['appro'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a1']['appro'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['basic_1'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['basic_1'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['appro_1'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['appro_1'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['compe_1'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['compe_1'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['outst_1'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['outst_1'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['appro_2'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['appro_2'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['compe_2'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['compe_2'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.2</td>
            @if ($evaluation->part1['p1a2']['outst_2'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a2']['outst_2'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            @if ($evaluation->part1['p1a3']['basic'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a3']['basic'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            @if ($evaluation->part1['p1a3']['appro'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a3']['appro'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1A.3</td>
            @if ($evaluation->part1['p1a3']['compe'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1a3']['compe'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            @if ($evaluation->part1['p1b1']['basic'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1b1']['basic'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            @if ($evaluation->part1['p1b1']['appro'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1b1']['appro'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        <tr>
            <td>{{ $evaluation->id }}</td>
            <td>{{ $evaluation->subject->name }}</td>
            <td>{{ $evaluation->schedule->class }}</td>
            <td>{{ $evaluation->user->name }}</td>
            <td>{{ $evaluation->user->email }}</td>
            <td>{{ $evaluation->teacher->fullname }}</td>
            <td>{{ $evaluation->teacher->email }}</td>
            <td></td>
            <td></td>
            <td>1B.1</td>
            @if ($evaluation->part1['p1b1']['compe'] == null)
            <td>0</td>
            <td>FALSE</td>
            @else
            <td>{{ $evaluation->part1['p1b1']['compe'] }}</td>
            <td>TRUE</td>
            @endif
        </tr>
        @endforeach
    </tbody>
</table>